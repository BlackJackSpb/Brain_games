### Hexlet tests and linter status:
[![Test Coverage](https://api.codeclimate.com/v1/badges/1587e1c523d919bb7dff/test_coverage)](https://codeclimate.com/github/BlackJackSpb/python-project-49/test_coverage)
[![Actions Status](https://github.com/BlackJackSpb/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/BlackJackSpb/python-project-49/actions)
